import hitung

hitung.tambah(19,1)
hitung.kurang(5,1)
hitung.kali(5,4)
hitung.bagi(4,2)
hitung.pangkat(2,2)
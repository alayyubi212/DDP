import math

def l_balok(p, l, t): 
    hitung = 2 * (p*1)+(p*t)+(1*t)
    print(f'luas balok adalah {hitung}')

def l_kubus (s):
    hitung = 6 * (s*s)
    print (f'luas kubus adalah {hitung}')

def l_tabung (r,t):
    hitung = 3,14 * r * r * t
    print (f'luas tabung adalah {hitung}')

def l_limas (alas,tinggi):
    hitung = 1/2 *alas*tinggi
    print (f'luas limas segitiga adalah {hitung}')

def l_prisma (l,k,t,a):
    hitung =2 * 1/2 * a * t + (k*t)
    print (f'luas prisma segitiga adalah {hitung}')
import bangunruang

bangunruang.l_balok(4,5,6)
bangunruang.l_kubus(4)
bangunruang.l_tabung(4, 5)
bangunruang.l_limas(4, 7)
bangunruang.l_prisma(4, 5, 6 , 9)
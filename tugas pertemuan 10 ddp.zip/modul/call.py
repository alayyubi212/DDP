import main 

print('--perhitungan persegi--')
main.l_persegi(19)

print('--perhitungan lingkaran--')
main.l_lingkaran(2)

print('--perhitungan persegi panjang--')
main.l_persegi_panjang(2,2)

print('--perhitungan jajargenjang--')
main.l_jajargenjang(1,3)

print('--perhitungan segitiga--')
main.l_segitiga(12,2)
